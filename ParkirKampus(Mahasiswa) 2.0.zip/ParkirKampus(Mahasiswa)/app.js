
const PLAT = 'L 1234 AB';
const MOTOR = 'Honda Vario 160';
const SLOT = 'C-024';
const DURASI_QR = 120;

const halaman = {
  location: { judul: 'Lokasi Parkir', sub: 'Cari tahu area dan slot tempat motor kamu diparkir.' },
  motor: { judul: 'Info Kendaraan', sub: 'Lihat detail motor dan lokasi parkir terakhir.' },
  time: { judul: 'Waktu Parkir & Keluar', sub: 'Cek waktu masuk, durasi parkir, dan waktu keluar.' },
  qr: { judul: 'QR Keluar', sub: 'Tunjukkan QR ini saat akan keluar kampus.' }
};

const state = {
  layar: 'login',
  fitur: 'location',
  modal: null,
  akun: '',
  nama: '',
  waktuMasuk: waktuAwal(),
  waktuKeluar: null,
  nomorTiket: 1,
  kodeTiket: '',
  tokenQr: '',
  batasQr: 0,
  gambarQr: ''
};
state.kodeTiket = buatKodeTiket();

let timer = null;
let toastTimer = null;

function $(id) {
  return document.getElementById(id);
}

function waktuAwal() {
  return new Date(Date.now() - 86 * 60000);
}

function buatKodeTiket() {
  const t = new Date();
  const tgl = t.getFullYear() + String(t.getMonth() + 1).padStart(2, '0') + String(t.getDate()).padStart(2, '0');
  return 'PK-' + tgl + '-' + String(state.nomorTiket).padStart(3, '0');
}

function jam(date) {
  return date.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', hour12: false });
}

function tanggal(date) {
  return date.toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });
}

function durasi(dari, sampai) {
  const menit = Math.max(0, Math.floor((sampai - dari) / 60000));
  const j = String(Math.floor(menit / 60)).padStart(2, '0');
  const m = String(menit % 60).padStart(2, '0');
  return j + 'j ' + m + 'm';
}

function tampilToast(pesan) {
  const el = $('toast');
  el.textContent = pesan;
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 2800);
}

function tokenBaru() {
  const acak = crypto.getRandomValues(new Uint8Array(4));
  return Array.from(acak, b => b.toString(16).padStart(2, '0')).join('').toUpperCase();
}

function buatQr() {
  const qr = new ParkirQr.QRCode(0, ParkirQr.CorrectLevel.H);
  qr.addData('KAMPUS-PARKIR|DEMO|' + state.kodeTiket + '|' + state.tokenQr);
  qr.make();

  const jumlah = qr.getModuleCount();
  const margin = 4;
  const ukuran = 8;
  const sisi = (jumlah + margin * 2) * ukuran;

  const canvas = document.createElement('canvas');
  canvas.width = sisi;
  canvas.height = sisi;
  const ctx = canvas.getContext('2d');
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, sisi, sisi);
  ctx.fillStyle = '#1f2a44';
  for (let r = 0; r < jumlah; r++) {
    for (let c = 0; c < jumlah; c++) {
      if (qr.isDark(r, c)) {
        ctx.fillRect((c + margin) * ukuran, (r + margin) * ukuran, ukuran, ukuran);
      }
    }
  }

  const tengah = sisi / 2;
  const logo = Math.round(jumlah * ukuran * 0.2);
  const bingkai = logo + ukuran * 2;
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(tengah - bingkai / 2, tengah - bingkai / 2, bingkai, bingkai);
  ctx.fillStyle = '#1f4e8c';
  ctx.fillRect(tengah - logo / 2, tengah - logo / 2, logo, logo);
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold ' + Math.round(logo * 0.7) + 'px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('P', tengah, tengah + logo * 0.03);

  state.gambarQr = canvas.toDataURL('image/png');
}

function segarkanQr() {
  state.tokenQr = tokenBaru();
  state.batasQr = Date.now() + DURASI_QR * 1000;
  buatQr();
}

function render() {
  const sudahLogin = state.layar !== 'login';
  const selesai = state.waktuKeluar !== null;
  const lama = durasi(state.waktuMasuk, state.waktuKeluar || new Date());

  const sisa = Math.max(0, Math.ceil((state.batasQr - Date.now()) / 1000));
  const hitungMundur = String(Math.floor(sisa / 60)).padStart(2, '0') + ':' + String(sisa % 60).padStart(2, '0');

  $('loginScreen').classList.toggle('hidden', sudahLogin);
  $('appScreen').classList.toggle('hidden', !sudahLogin);
  $('appScreen').classList.toggle('detail-active', state.layar === 'fitur');
  $('campusHomeView').classList.toggle('hidden', state.layar === 'fitur');
  $('featureDetailView').classList.toggle('hidden', state.layar !== 'fitur');

  $('featurePageTitle').textContent = halaman[state.fitur].judul;
  $('featurePageSubtitle').textContent = halaman[state.fitur].sub;
  for (const nama in halaman) {
    $('feature-' + nama).classList.toggle('hidden', nama !== state.fitur);
  }
  document.querySelectorAll('[data-open-feature]').forEach(tombol => {
    tombol.setAttribute('aria-pressed', String(tombol.dataset.openFeature === state.fitur));
  });

  $('qrModal').classList.toggle('hidden', state.modal !== 'qr');
  $('logoutModal').classList.toggle('hidden', state.modal !== 'logout');

  const nama = state.nama || 'Mahasiswa';
  $('profileName').textContent = nama;
  $('profileAccount').textContent = 'SSO: ' + state.akun.split('@')[0];
  $('homeTitle').textContent = 'Halo, ' + nama + '!';
  $('avatarInitial').textContent = nama.charAt(0).toUpperCase();

  $('plateSummary').textContent = PLAT;
  $('plateDetail').textContent = PLAT;
  $('homeVehicleSummary').textContent = MOTOR + ' · ' + PLAT;
  $('timeEntry').textContent = jam(state.waktuMasuk);
  $('timeEntryDate').textContent = tanggal(state.waktuMasuk);
  $('timeDuration').textContent = lama;
  $('homeDuration').textContent = lama;
  $('timelineEntry').textContent = tanggal(state.waktuMasuk) + ', ' + jam(state.waktuMasuk) + ' · Gerbang Timur';

  $('homeSessionState').textContent = selesai ? 'Selesai' : 'Aktif';
  $('homeSessionState').classList.toggle('done', selesai);
  $('exitTimeline').classList.toggle('pending', !selesai);
  $('motorStatus').textContent = selesai ? 'Sudah keluar' : 'Masih terparkir';

  if (selesai) {
    $('homeParkingStatus').textContent = 'Motor sudah keluar pukul ' + jam(state.waktuKeluar);
    $('timeExit').textContent = jam(state.waktuKeluar);
    $('timeExitDate').textContent = tanggal(state.waktuKeluar);
    $('timelineExitTitle').textContent = 'Kendaraan keluar';
    $('timelineExit').textContent = tanggal(state.waktuKeluar) + ', ' + jam(state.waktuKeluar) + ' · Gerbang Timur';
  } else {
    $('homeParkingStatus').textContent = 'Motor kamu terparkir di ' + SLOT;
    $('timeExit').textContent = 'Belum';
    $('timeExitDate').textContent = 'Akan tercatat saat QR divalidasi';
    $('timelineExitTitle').textContent = 'Motor masih terparkir';
    $('timelineExit').textContent = 'Waktu keluar tercatat setelah QR divalidasi di gerbang.';
  }

  $('qrValidationState').textContent = selesai ? '● QR SUDAH DIPAKAI' : '● QR MASIH AKTIF';
  $('qrValidationState').classList.toggle('done', selesai);
  $('qrActive').classList.toggle('hidden', selesai);
  $('qrInactive').classList.toggle('hidden', !selesai);
  $('exitDone').classList.toggle('hidden', !selesai);
  $('validateBtn').disabled = selesai;
  $('validateBtn').textContent = selesai ? 'QR sudah digunakan' : 'Simulasikan validasi keluar';
  $('qrCountdown').textContent = hitungMundur;
  $('modalCountdown').textContent = hitungMundur;
  $('qrTicketCode').textContent = state.kodeTiket;
  $('modalTicketCode').textContent = state.kodeTiket;

  if ($('qrImage').getAttribute('src') !== state.gambarQr) {
    $('qrImage').src = state.gambarQr;
    $('modalQrImage').src = state.gambarQr;
  }
}

function detak() {
  if (!state.waktuKeluar && Date.now() >= state.batasQr) {
    segarkanQr();
    tampilToast('QR sudah diperbarui otomatis.');
  }
  render();
}

function mulaiTimer() {
  clearInterval(timer);
  timer = setInterval(detak, 1000);
}

function pindahKe(layar, fitur) {
  state.layar = layar;
  if (fitur) state.fitur = fitur;
  window.scrollTo(0, 0);
  render();
}

function bukaModal(nama) {
  state.modal = nama;
  render();
}

function tutupModal() {
  state.modal = null;
  render();
}

document.querySelectorAll('.app-feature-card').forEach(kartu => {
  kartu.addEventListener('click', () => pindahKe('fitur', kartu.dataset.feature));
});
document.querySelectorAll('[data-open-feature]').forEach(tombol => {
  tombol.addEventListener('click', () => pindahKe('fitur', tombol.dataset.openFeature));
});
$('backToAppsBtn').addEventListener('click', () => pindahKe('beranda'));

$('enlargeQrBtn').addEventListener('click', () => {
  if (state.waktuKeluar) {
    tampilToast('QR sudah tidak berlaku karena sesi parkir selesai.');
    return;
  }
  bukaModal('qr');
});
$('logoutBtn').addEventListener('click', () => bukaModal('logout'));
$('closeModalBtn').addEventListener('click', tutupModal);
$('cancelLogoutBtn').addEventListener('click', tutupModal);

['qrModal', 'logoutModal'].forEach(id => {
  $(id).addEventListener('click', e => {
    if (e.target === $(id)) tutupModal();
  });
});
document.addEventListener('keydown', e => {
  if (e.key === 'Escape' && state.modal) tutupModal();
});

$('refreshQrBtn').addEventListener('click', () => {
  const tombol = $('refreshQrBtn');
  tombol.classList.add('spin');
  setTimeout(() => tombol.classList.remove('spin'), 600);
  segarkanQr();
  render();
  tampilToast('QR berhasil dimuat ulang.');
});

function validasiKeluar() {
  if (state.waktuKeluar) {
    tampilToast('QR ini sudah pernah digunakan.');
    return;
  }
  state.waktuKeluar = new Date();
  state.modal = null;
  render();
  tampilToast('Berhasil! Waktu keluar sudah tercatat (versi demo).');
}

function sesiBaru() {
  state.waktuMasuk = new Date();
  state.waktuKeluar = null;
  state.nomorTiket++;
  state.kodeTiket = buatKodeTiket();
  segarkanQr();
  render();
  tampilToast('Sesi parkir baru sudah dimulai.');
}

$('validateBtn').addEventListener('click', validasiKeluar);
$('modalValidateBtn').addEventListener('click', validasiKeluar);
$('resetDemoBtn').addEventListener('click', sesiBaru);

$('copyQrBtn').addEventListener('click', () => {
  navigator.clipboard.writeText(state.kodeTiket)
    .then(() => tampilToast('Kode tiket sudah disalin.'))
    .catch(() => tampilToast('Kode tiket: ' + state.kodeTiket));
});

function namaDariAkun(akun) {
  const depan = akun.split('@')[0];
  const kata = depan.replace(/[0-9._-]+/g, ' ').trim().split(/\s+/).filter(Boolean);
  if (kata.length === 0) return 'Mahasiswa';
  return kata.slice(0, 3)
    .map(k => k.charAt(0).toUpperCase() + k.slice(1).toLowerCase())
    .join(' ');
}

$('loginForm').addEventListener('submit', e => {
  e.preventDefault();
  const akun = $('sso').value.trim();
  const password = $('ssoPassword').value;

  if (!akun) {
    $('loginError').textContent = 'Masukkan akun SSO kampus terlebih dahulu.';
    return;
  }
  if (!password) {
    $('loginError').textContent = 'Masukkan password untuk melanjutkan.';
    return;
  }

  $('ssoPassword').value = '';
  $('loginError').textContent = '';

  state.akun = akun;
  state.nama = namaDariAkun(akun);
  segarkanQr();
  mulaiTimer();
  pindahKe('beranda');
});

$('toggleSsoPassword').addEventListener('click', () => {
  const input = $('ssoPassword');
  const tampil = input.type === 'password';
  input.type = tampil ? 'text' : 'password';
  $('toggleSsoPassword').textContent = tampil ? 'Sembunyikan' : 'Lihat';
});

$('confirmLogoutBtn').addEventListener('click', () => {
  clearInterval(timer);
  $('sso').value = '';
  $('ssoPassword').value = '';

  state.layar = 'login';
  state.modal = null;
  state.akun = '';
  state.nama = '';
  state.waktuMasuk = waktuAwal();
  state.waktuKeluar = null;
  state.nomorTiket++;
  state.kodeTiket = buatKodeTiket();
  segarkanQr();
  render();
  tampilToast('Kamu sudah keluar dari akun demo.');
});

['forgotBtn', 'loginHelpBtn', 'homeHelpBtn'].forEach(id => {
  $(id).addEventListener('click', () => {
    tampilToast('Kontak helpdesk belum diatur di versi demo ini.');
  });
});

segarkanQr();
render();
